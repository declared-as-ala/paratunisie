"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ShieldCheck, Truck, CreditCard, Sparkles, Zap } from "lucide-react";

export function HomeHero() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReducedMotion(motionQuery.matches);

    const handler = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
    motionQuery.addEventListener("change", handler);
    return () => motionQuery.removeEventListener("change", handler);
  }, []);

  useEffect(() => {
    if (prefersReducedMotion && videoRef.current) {
      videoRef.current.pause();
    }
  }, [prefersReducedMotion]);

  return (
    <section className="relative w-full overflow-hidden bg-[#FAF7F5] border-b border-border/40">
      {/* ── 1. Hero Media Background (Video + Poster Fallback) ─────────── */}
      <div className="absolute inset-0 z-0 select-none">
        {/* Base Poster Image (Instant paint & SEO / Reduced Motion fallback) */}
        <Image
          src="/assets/hero-poster.webp"
          alt="ParaTunisie — Parapharmacie & Nutrition sportive en Tunisie"
          fill
          priority
          sizes="100vw"
          className="object-cover object-[58%_center] sm:object-[56%_center] lg:object-[58%_center]"
        />

        {/* HTML5 Autoplay Video Layer */}
        {!prefersReducedMotion && (
          <video
            ref={videoRef}
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
            poster="/assets/hero-poster.webp"
            aria-hidden="true"
            className="absolute inset-0 h-full w-full object-cover object-[58%_center] sm:object-[56%_center] lg:object-[58%_center] transition-opacity duration-700"
          >
            <source src="/assets/hero-video-optimized.mp4" type="video/mp4" />
            <source
              src="/assets/hf_20260826_190907_af0b25d6-4401-4b39-8132-c86ed8c156f1.mp4"
              type="video/mp4"
            />
          </video>
        )}

        {/* ── Desktop Left Readability Gradient (Gentle luminance mask) ── */}
        <div
          className="hidden md:block absolute inset-0 bg-gradient-to-r from-white/95 via-white/75 via-42% to-transparent pointer-events-none"
          aria-hidden="true"
        />

        {/* ── Mobile Vignette (Soft top and bottom fade) ───────────────── */}
        <div
          className="md:hidden absolute inset-0 bg-gradient-to-b from-white/30 via-transparent to-[#FAF7F5] pointer-events-none"
          aria-hidden="true"
        />

        {/* ── Bottom Section Seamless Transition Blend ───────────────── */}
        <div
          className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#FAF7F5] via-[#FAF7F5]/40 to-transparent pointer-events-none"
          aria-hidden="true"
        />
      </div>

      {/* ── 2. Hero Foreground Content & Typography ───────────────────── */}
      <div className="relative z-10 mx-auto flex min-h-[85vh] sm:min-h-[88vh] lg:min-h-[92vh] max-w-[1440px] items-center px-4 sm:px-8 lg:px-16 py-12 sm:py-16">
        <div className="w-full max-w-xl lg:max-w-2xl">
          {/* Glassmorphic card on mobile / pure typographic block on desktop */}
          <div className="rounded-3xl border border-white/70 bg-white/85 p-6 shadow-xl backdrop-blur-md sm:border-transparent sm:bg-transparent sm:p-0 sm:shadow-none sm:backdrop-blur-none">
            {/* Eyebrow Pill */}
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3.5 py-1.5 text-[0.6875rem] font-extrabold uppercase tracking-wider text-primary shadow-2xs">
              <Sparkles size={13} className="text-primary animate-pulse" />
              <span>Votre Parapharmacie & Nutrition en Tunisie</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif text-3xl font-bold leading-[1.08] tracking-tight text-ink sm:text-4xl md:text-5xl lg:text-[3.5rem]">
              Votre bien-être.
              <br />
              <span className="text-primary font-extrabold">Votre performance.</span>
            </h1>

            {/* Subtitle */}
            <p className="mt-4 max-w-lg text-sm sm:text-base leading-relaxed text-ink/80 font-normal">
              Parapharmacie d&apos;élite, soins dermatologiques haute tolérance, vitamines certifiées et nutrition sportive 100% authentique pour votre quotidien.
            </p>

            {/* Dual CTAs */}
            <div className="mt-8 flex flex-col gap-3.5 sm:flex-row sm:items-center">
              {/* Primary CTA -> Main Shop Catalog */}
              <Link
                href="/shop"
                className="group inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-primary px-7 py-3.5 text-sm font-bold text-white shadow-md shadow-primary/20 hover:bg-primary-hover hover:shadow-lg active:scale-98 transition-all"
              >
                <span>Découvrir nos produits</span>
                <ArrowRight
                  size={16}
                  className="transition-transform duration-200 group-hover:translate-x-1"
                />
              </Link>

              {/* Secondary CTA -> Sports Nutrition */}
              <Link
                href="/creatine"
                className="inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl border border-primary/25 bg-white/80 px-6 py-3.5 text-sm font-bold text-ink backdrop-blur-xs hover:border-primary hover:bg-white hover:text-primary active:scale-98 transition-all shadow-2xs"
              >
                <Zap size={15} className="text-primary" />
                <span>Nutrition sportive</span>
              </Link>
            </div>

            {/* Trust Badges Strip */}
            <div className="mt-8 pt-6 border-t border-border/60 flex flex-wrap items-center gap-x-5 gap-y-2.5 text-xs font-semibold text-ink-muted">
              <span className="inline-flex items-center gap-1.5 text-ink/90">
                <ShieldCheck size={16} className="text-emerald-600 shrink-0" />
                100% Produits Authentiques
              </span>
              <span className="inline-flex items-center gap-1.5 text-ink/90">
                <Truck size={16} className="text-emerald-600 shrink-0" />
                Livraison 24-48h en Tunisie
              </span>
              <span className="inline-flex items-center gap-1.5 text-ink/90">
                <CreditCard size={16} className="text-emerald-600 shrink-0" />
                Paiement à la livraison
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
